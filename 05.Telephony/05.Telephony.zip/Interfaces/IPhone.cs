﻿public interface IPhone : IBrowsing, ICalling
{
}
