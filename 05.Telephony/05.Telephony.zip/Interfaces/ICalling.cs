﻿public interface ICalling
{
    string MakeCall(string number);
}
