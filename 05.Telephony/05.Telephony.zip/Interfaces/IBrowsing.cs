﻿public interface IBrowsing
{
    string Browsing(string url);
}
